package br.edu.etec.appmrv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TelaJava2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_design_2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Spinner listaEstados = findViewById(R.id.spn_estados);
        String[] nomesEstados = {"RS", "SC", "PR", "SP", "RJ", "ES", "MG"};
        ArrayAdapter<String> preencherSpinnerAoIniciar;
        preencherSpinnerAoIniciar = new
                ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item, nomesEstados);
        listaEstados.setAdapter(preencherSpinnerAoIniciar);
        Button botao = findViewById(R.id.btn_estados);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent abrirTela = new Intent(TelaJava2.this, TelaJava3.class);
                startActivity(abrirTela);

            }
        });

    }
}